package assignment01;

import java.util.List;

public class MSCSAIChecker implements Checker {

	@Override
	public boolean satisfies(List<String> taken) {
		// TODO Auto-generated method stub
		return false;
	}
}
